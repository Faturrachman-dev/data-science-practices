```
└── 📁dashboard
    └── dashboard.py
    └── PRSA_Data_Aotizhongxin_20130301-20170228.csv
```